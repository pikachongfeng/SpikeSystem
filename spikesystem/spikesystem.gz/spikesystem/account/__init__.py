import pymysql ##引入mysql
pymysql.install_as_MySQLdb()